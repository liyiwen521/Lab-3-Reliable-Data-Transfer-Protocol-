import config
import threading
import time
import udt
import util

class SelectiveRepeat:


    # constructor for SelectiveRepeat
    def __init__(self, local_port, remote_port, msg_handler):
        util.log("Starting up `SelectiveRepeat` protocol ... ")
        self.network_layer = udt.NetworkLayer(local_port, remote_port, self)
        # "msg_handler" is used to deliver messages to application layer
        self.msg_handler = msg_handler
        self.sender_base = 0
        self.next_sequence_number = 0
        self.window = [b''] * config.WINDOW_SIZE
        self.expected_sequence_number = 0
        self.receiver_last_ack = b''
        self.is_receiver = True
        self.sender_lock = threading.Lock()
        self.buffer_rec = [b''] * config.WINDOW_SIZE
        self.rec_list = [False] * config.WINDOW_SIZE
        self.buffer_send = [False] * config.WINDOW_SIZE
        self.buffer_timer = [self.set_timer(-1)] * config.WINDOW_SIZE

    def set_timer(self, seq_num):
        return threading.Timer((config.TIMEOUT_MSEC / 1000.0), self._timeout,
                               {seq_num: seq_num})


    # Helper fn for thread to send the next packet
    def _send_helper(self, msg):
        self.sender_lock.acquire()

        packet = util.make_packet(msg, config.MSG_TYPE_DATA,
                                  self.next_sequence_number)
        packet_data = util.extract_data(packet)
        util.log("Sending data: " + util.pkt_to_string(packet_data))
        self.network_layer.send(packet)
        if self.sender_base + config.WINDOW_SIZE>self.next_sequence_number:
            idx_in_buffer = (self.next_sequence_number -
                             self.sender_base) % config.WINDOW_SIZE
            self.window[idx_in_buffer] = packet
            self.buffer_send[idx_in_buffer] = False
            self.buffer_timer[idx_in_buffer] = self.set_timer(
                self.next_sequence_number)
            self.buffer_timer[idx_in_buffer].start()
            self.next_sequence_number += 1

        else:
            pass
        self.sender_lock.release()
        
        return


    # Application will call send and return turn for a succss false for fail.
    # add the timer into timer buffer
    def send(self, msg):
        self.is_receiver = False
        if (self.sender_base + config.WINDOW_SIZE) > self.next_sequence_number :
            self._send_helper(msg)
            return True
        else:
            util.log("Window is full. App data rejected.")
            time.sleep(1)
            return False

    # Network layer call handler when packet is ready

    def handle_arrival_msg(self):
        msg = self.network_layer.recv()
        msg_data = util.extract_data(msg)

        if (msg_data.is_corrupt):
            # wait for time out
            return

        # If ACK message, assume its for sender

        if msg_data.msg_type == config.MSG_TYPE_ACK:
            self.sender_lock.acquire()

            idx_in_buffer = (msg_data.seq_num -
                             self.sender_base) % config.WINDOW_SIZE
            self.buffer_send[idx_in_buffer] = True
            util.log('received the ask for' + str(idx_in_buffer) +
                     'Cancle the timer')
            self.buffer_timer[idx_in_buffer].cancel()
            self.buffer_timer[idx_in_buffer] = self.set_timer(msg_data.seq_num)
            # need to check the whether the first element in the sender
            # check whether buffer is acked or not, if yes we slide the window
            try:
                while self.buffer_send[0]:
                    self.sender_base += 1
                    self.buffer_send = self.buffer_send[1:] + [False]
                    self.buffer_timer = self.buffer_timer[1:] + [
                        self.set_timer(-1)
                    ]
                    self.window = self.window[1:] + [b'']
                    # util.log('Window slide to the right')
            except IndexError:
                pass
            self.sender_lock.release()
        else:
            assert msg_data.msg_type == config.MSG_TYPE_DATA
            util.log("Received DATA: " + util.pkt_to_string(msg_data))
            ack_pkt = util.make_packet(b'', config.MSG_TYPE_ACK,
                                       msg_data.seq_num)
            if self.expected_sequence_number <= msg_data.seq_num <= self.expected_sequence_number + config.WINDOW_SIZE - 1:
                # send the content of the packet to the application layer
                self.network_layer.send(ack_pkt)
                util.log("Sent ACK: " +
                         util.pkt_to_string(util.extract_data(ack_pkt)))
                idx_in_buffer = (
                    msg_data.seq_num -
                    self.expected_sequence_number) % config.WINDOW_SIZE

                self.rec_list[idx_in_buffer] = True
                if msg_data.seq_num == self.expected_sequence_number:
                    self.buffer_rec[idx_in_buffer] = msg_data.payload
                    while self.rec_list[0]:
                        self.msg_handler(self.buffer_rec[0])
                        self.expected_sequence_number += 1
                        self.rec_list = self.rec_list[1:] + [False]
                        self.buffer_rec = self.buffer_rec[1:] + [b'']
                        util.log('reciver window slides to the right')

                    
                else:
                    self.buffer_rec[idx_in_buffer] = msg_data.payload

                    util.log("APP recived the message " +
                             str(msg_data.seq_num))
            elif msg_data.seq_num < self.expected_sequence_number:
                # ack_pkt = util.make_packet(b'', config.MSG_TYPE_ACK,
                #                            self.expected_sequence_number)
                self.network_layer.send(ack_pkt)
                util.log("Sent ACK: " +
                         util.pkt_to_string(util.extract_data(ack_pkt)))
            else:
                return
        return

# Cleanup resources.
    def shutdown(self):
        if not self.is_receiver: self._wait_for_last_ACK()
        for timer in self.buffer_timer:
            if timer.is_alive():
                timer.cancel()
        util.log("Connection shutting down...")
        self.network_layer.shutdown()

    def _wait_for_last_ACK(self):
        while self.sender_base < self.next_sequence_number - 1:
            util.log("Waiting for last ACK from receiver with sequence # " +
                     str(int(self.next_sequence_number - 1)) + ".")
            time.sleep(1)





    def _timeout(self, seq_num):
        util.log("Resending packets with seq #s " + str(seq_num) + ".")
        self.sender_lock.acquire()
        # timer_check = self.buffer_timer[(seq_num-self.sender_base) % config.WINDOW_SIZE]
        idx_in_buffer = (seq_num - self.sender_base) % config.WINDOW_SIZE
        self.buffer_timer[idx_in_buffer].cancel()
        self.buffer_timer[idx_in_buffer] = self.set_timer(seq_num)
        pkt = self.window[idx_in_buffer]
        self.network_layer.send(pkt)
        util.log("Resending packet: " +
                 util.pkt_to_string(util.extract_data(pkt)))
        self.buffer_timer[idx_in_buffer].start()
        self.sender_lock.release()
        return
